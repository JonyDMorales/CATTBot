# Trabajo Terminal
Este es el codigo del middleware para mi trabajo terminal.
